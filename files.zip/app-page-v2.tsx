// Replace the ENTIRE contents of app/page.tsx with this.

import Link from 'next/link'

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="px-8 py-6 rule">
        <span className="font-display text-lg italic">Project Topic Selection</span>
      </header>

      <main className="flex-1 flex items-center justify-center px-6">
        <div className="ledger-card max-w-lg w-full px-10 py-12 text-center">
          <h1 className="font-display italic text-4xl mb-4">Welcome</h1>
          <p className="text-[var(--color-ink-soft)] mb-10 leading-relaxed">
            Select and manage your final-year project topic, track progress,
            and stay in sync with your department — all in one place.
          </p>

          <div className="flex gap-4 justify-center">
            <Link href="/login/student" className="btn-primary">
              Student Login
            </Link>
            <Link href="/login/hod" className="btn-secondary">
              HoD Login
            </Link>
          </div>
        </div>
      </main>

      <footer className="px-8 py-6 rule text-sm text-[var(--color-ink-soft)] text-center">
        © {new Date().getFullYear()} Project Topic Selection
      </footer>
    </div>
  )
}
